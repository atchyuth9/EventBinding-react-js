import React, { Fragment } from "react";
import Event from "./Event";
let App = () => {
  return (
    <Fragment>
      <nav className="nav">
        <a href="/">Achyuth</a>
      </nav>
      <Event />
    </Fragment>
  );
};

export default App;
